"""Streamlit dashboard entry point."""
